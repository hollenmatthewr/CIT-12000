var name = prompt("what is your name?");
var last = prompt("what is your last name?");

document.body.innerHTML = name+" is my first name. My last name is "+last;