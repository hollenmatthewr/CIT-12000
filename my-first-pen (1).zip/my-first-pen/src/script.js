var name = prompt("what is your name?");
var color = prompt("what is your favorite color?");

document.body.innerHTML = "My name is" + " " + name  + " " + "and my favorite color is" + " " + color;